<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'kkwordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'KF;(FJ$vu/jl5pWnF`1^ y#<B$!39j37rSvIN9W%)Z/~O>~oZE9LMUIKm9Go%o=|' );
define( 'SECURE_AUTH_KEY',  '^R[x.i;Qp*O(XY%wC Y,lX0y]CE-lHx&kcq_1}ghx|M%3fzEB[m*_yvvZxm7x@W+' );
define( 'LOGGED_IN_KEY',    'Nls^&nG<zk|vCAC{({Zl5ncR$3_r!E*y(i3>j)N# -WSpU9RUs_@dOU4~gA]kvsp' );
define( 'NONCE_KEY',        '>iLh~3!g?*DELf_a%z<*w~|^/se~)U-P|Jq0oulz>Z87H2zTrJOMlx6!KadL-Yx_' );
define( 'AUTH_SALT',        'oXGO^x)X%i3Id;UKcp<URP(vW?Rc5H{|hDmC!/,*JulqH(0O^|e,t.&O<:ldRVlM' );
define( 'SECURE_AUTH_SALT', '_b8~=BJIrsKtoZ?4q`j(Wcodmup>j_LiuwnJv/V-LuYCnQUaf`Cy)~1}f!O^z<*n' );
define( 'LOGGED_IN_SALT',   'F Cu,(H,v21vZg-B d>#GQ)b0oadPa&96z6|KN/95W*>]hIB|O#>CmF0HZ%#B|LE' );
define( 'NONCE_SALT',       '0t&$,q,pGBz58vc-E!**`ouzx/V`U&0ogxy3-1E~%#K4Kx2O@v.]4;Hn[UB=1zRH' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
